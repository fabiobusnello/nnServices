const changeModules = () => {
    $('.menus li').click(async (e) => {
        if (e.target.nodeName === "I") {
            return $(e.target).parent().parent().click()
        }
        const moduleName = $(e.target).data('module')
        if (moduleName) {
            try {
                const fnModule = await import(`../${moduleName.toLowerCase()}`)
                await fnModule.default()
                $(".sidebar").animate({ 'left': '-200px' }, 200)

            } catch (error) {
                await ajax({url: 'modules', method: 'post', body: {moduleName}})
            }

        }
    })
}

export default changeModules