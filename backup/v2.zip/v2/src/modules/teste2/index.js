const component = () => {
    return `<div style="background-color:#fff">teste2</div>`
}
const teste2 = ()=>{
    document.querySelector(".contents").innerHTML = component()
}

export default teste2