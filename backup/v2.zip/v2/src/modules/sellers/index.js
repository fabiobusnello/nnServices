const component = () => {
    return `<div style="background-color:#fff">vendedores</div>`
}
const sellers = ()=>{
    $(".contents").html(component())
}

export default sellers