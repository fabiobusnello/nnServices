const component = () => {
    return `<div style="background-color:#fff">11</div>`
}
const 11 = ()=>{
    document.querySelector(".contents").innerHTML = component()
}

export default 11