const component = () => {
    return `<div style="background-color:#fff">17</div>`
}
const 17 = ()=>{
    document.querySelector(".contents").innerHTML = component()
}

export default 17