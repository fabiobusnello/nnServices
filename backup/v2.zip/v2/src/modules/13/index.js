const component = () => {
    return `<div style="background-color:#fff">13</div>`
}
const 13 = ()=>{
    document.querySelector(".contents").innerHTML = component()
}

export default 13