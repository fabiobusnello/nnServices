import formSearsh from "./company-searsh";

const companyContainer = () => {
    const component = `<div class="content-empresas" style="display:none">
    <nav class="navbar navbar-expand-lg navbar-company">
        <div class="container-fluid">
           <div > <h5>Empresas</h5> </div>
           <div > </div>
          
             <div class="col-md-5">
                    <div class="input-group search-company">
                        <i id="company-searsh-button" class="fas fa-search search-company-loop"></i>
                        <input type="text" class="form-control seach-company input-seach-company" placeholder="Procurar Empresa">
                        <div class="input-group-prepend" >
                            <div class="input-group-text" id="add-company" title="Adicionar Empresas" >
                                <i class="fas fa-plus" ></i>
                            </div>
                        </div>
                </div>
                </div>
           
        </div>
    </nav>

    <table class="table table-dark table-hover">
        <thead>
            <tr>
                <th scope="col">Empresa</th>
                <th scope="col">C.N.P.J.</th>
                <th scope="col">I.E.</th>
            </tr>
        </thead>
        <tbody>
           
        </tbody>
    </table>
    <div id="company-form1"></div>
</div>
`
    document.querySelector(".contents").innerHTML = component
    document.querySelector("#company-searsh-button").onclick = (e) => {
        formSearsh()
    }
}

export default companyContainer