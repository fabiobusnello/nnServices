import './searsh.css'
const formSearch = () => {
    const component = `
    <div class="modal fade" id="modal-company-searsh" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title mx-sm-2">Pesquisar avançada</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">

                <form class="form" id="form-company-seash">

                    <div class="form-group mb-2 mx-sm-3">
                        <div class="group">
                            <input type="text" placeholder=" " autocomplete="off" name="companyRazao">
                            <span class="bar"></span>
                            <label>Razão Social</label>
                        </div>
                    </div>

                    <div class="form-group mb-2 mx-sm-3">
                        <div class="group">
                            <input type="text" placeholder=" " autocomplete="off" name="companyFantasia">
                            <span class="bar"></span>
                            <label>Nome Fantasia</label>
                        </div>
                    </div>

                    <div class="form-inline">

                        <div class="form-group mb-2 mx-sm-3">
                            <div class="group">
                                <input type="text" placeholder=" " autocomplete="off" name="cnpj">
                                <span class="bar"></span>
                                <label>CNPJ</label>
                            </div>
                        </div>

                        <div class="form-group mb-2 mx-sm-3 ">
                            <div class="group">
                                <input type="text" placeholder=" " autocomplete="off" name="ie">
                                <span class="bar"></span>
                                <label>Inscrição Estadual</label>
                            </div>
                        </div>

                        <div class="form-group mb-2 mx-sm-3">
                            <div class="group">
                                <input type="text" placeholder=" " autocomplete="off" name="im">
                                <span class="bar"></span>
                                <label>Inscrição Municipal</label>
                            </div>
                        </div>

                        <div class="form-group mb-2 mx-sm-3">
                            <div class="group">
                                <input type="text" placeholder=" " autocomplete="off" name="cep">
                                <span class="bar"></span>
                                <label>CEP</label>
                            </div>
                        </div>

                        <div class="form-group mb-2 mx-sm-3">
                            <div class="group">
                                <input type="text" placeholder=" " autocomplete="off" name="endereco">
                                <span class="bar"></span>
                                <label>Endereço</label>
                            </div>
                        </div>

                        <div class="form-group mb-2 mx-sm-3">
                            <div class="group">
                                <input type="number" placeholder=" " autocomplete="off" name="numero">
                                <span class="bar"></span>
                                <label>Número</label>
                            </div>
                        </div>

                        <div class="form-group mb-2 mx-sm-3">
                            <div class="group">
                                <input type="text" placeholder=" " autocomplete="off" name="complemento">
                                <span class="bar"></span>
                                <label>Complemento</label>
                            </div>
                        </div>

                        <div class="form-group mb-2 mx-sm-3">
                            <div class="group">
                                <input type="text" placeholder=" " autocomplete="off" name="bairro">
                                <span class="bar"></span>
                                <label>Bairro</label>
                            </div>
                        </div>

                        <div class="form-group mb-2 mx-sm-3">
                            <div class="group">
                                <input type="text" placeholder=" " autocomplete="off" name="cidade">
                                <span class="bar"></span>
                                <label>Cidade</label>
                            </div>
                        </div>

                        <div class="form-group mb-2 mx-sm-3">
                            <div class="group">
                                <input type="text" placeholder=" " autocomplete="off" name="uf">
                                <span class="bar"></span>
                                <label>UF</label>
                            </div>
                        </div>
                    
                    </div>
                    
                    <input type="submit" id="send-searsh" style="display:none">

                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-primary" onclick="$('#send-searsh').click()">Salvar</button>
            </div>
        </div>
    </div>
</div>
    `
    document.querySelector('#company-form1').innerHTML = component
    $('#modal-company-searsh').modal('show')
    $('#modal-company-searsh').on('hidden.bs.modal', () => {
        $('#modal-company-searsh').remove()
    })
}

export default formSearch