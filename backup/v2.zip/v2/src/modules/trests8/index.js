const component = () => {
    return `<div style="background-color:#fff">trests8</div>`
}
const trests8 = ()=>{
    document.querySelector(".contents").innerHTML = component()
}

export default trests8