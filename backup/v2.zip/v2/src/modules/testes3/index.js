const component = () => {
    return `<div style="background-color:#fff">testes3</div>`
}
const testes3 = ()=>{
    document.querySelector(".contents").innerHTML = component()
}

export default testes3