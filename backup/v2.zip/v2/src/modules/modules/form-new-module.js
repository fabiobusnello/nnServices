import { alerts } from "../alerts";

const formNewModule = () => {
    const component = `<div class="modal fade" id="modal-new-module" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title mx-sm-2">Adicionar Módulo</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">

                <form class="form" id="form-new-module" onsubmit="return false" method="post">

                    <div class="form-group mb-2 mx-sm-3">
                        <div class="group">
                            <input type="text" placeholder=" " autocomplete="off" name="name" required>
                            <span class="bar"></span>
                            <label>Nome do módulo para exibição</label>
                        </div>
                    </div>

                    <div class="form-group mb-2 mx-sm-3">
                        <div class="group">
                            <input type="text" placeholder=" " autocomplete="off" name="moduleName" required>
                            <span class="bar"></span>
                            <label>Nome do que será criado</label>
                        </div>
                    </div>

                    <div class="form-inline">

                        <div class="form-group mb-2 mx-sm-3">
                            <div class="group">
                                <input type="text" placeholder=" " autocomplete="off" name="icon" required>
                                <span class="bar"></span>
                                <label>Ícone</label>
                            </div>
                        </div>
                    
                    </div>
                    
                    <input type="submit" id="send-new-module" style="display:none">

                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-primary" onclick="$('#send-new-module').click()">Salvar</button>
            </div>
        </div>
    </div>
</div>`

document.querySelector("#module-form").innerHTML = component
$("#modal-new-module").modal('show')
sendNewModule()
}

const sendNewModule = () => {
    document.querySelector('#form-new-module').onsubmit = (e)=>{
        ajax({ url: 'modules', method: 'post', body: { name: e.target.name.value, moduleName: e.target.moduleName.value, icon: e.target.icon.value } })
        .then(data=>{
            location.reload()
        })
        .catch(err => {
            alerts({message: '<strong><i class="far fa-frown fa-2x"></i></strong> Houve algum erro e infelismente sua solicitação não pode ser atendida! desculme-nos...'})
        })
        return false
    }
}
export default formNewModule