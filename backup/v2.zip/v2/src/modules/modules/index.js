import './modules.css'
import formNewModule from './form-new-module';
const component = () => {
    return `<div id="module-container" style="display: none">
    
    <nav class="navbar navbar-expand-lg navbar-modules">
        <div class="container-fluid">
           <div > <h5>Modulos</h5> </div>
           <div > </div>
          
             <div class="col-md-5">
                    <div class="input-group search-modules">
                        <i id="modules-searsh-button" class="fas fa-search search-modules-loop"></i>
                        <input type="text" class="form-control seach-modules input-seach-modules" placeholder="Procurar modulos">
                        <div class="input-group-prepend" >
                            <div class="input-group-text" id="add-modules" title="Adicionar modulo" >
                                <i class="fas fa-plus" ></i>
                            </div>
                        </div>
                </div>
                </div>
           
        </div>
    </nav>

    <table class="table table-dark table-hover">
        <thead>
            <tr>
                <th scope="col">Nome</th>
                <th scope="col">Modulo</th>
                <th scope="col">Icone</th>
            </tr>
        </thead>
        <tbody id="tbody-modules">
           
        </tbody>
    </table>
    <div id="module-form"></div>
</div>
`
}

const addNewModule = ()=>{
    document.querySelector('#add-modules').onclick = ()=>{
        formNewModule()
    }    
}

const changeModules = async () =>{
    const {data} = await ajax({url: 'modules'})
    let html = ""
    data.forEach(modules => {
        html += `<tr>
        <td>${modules.name}</td>
        <td>${modules.moduleName}</td>
        <td>${modules.icon}</td>
        </tr>`
    });
    document.querySelector('#tbody-modules').innerHTML = html
}

const modules = ()=>{
    document.querySelector(".contents").innerHTML = component()
    $('#module-container').show('fast')
    changeModules()
    addNewModule()
}
export default modules