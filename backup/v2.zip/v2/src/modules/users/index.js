const component = () => {
    return `<div style="background-color:#fff">users</div>`
}
const users = ()=>{
    document.querySelector(".contents").innerHTML = component()
}

export default users