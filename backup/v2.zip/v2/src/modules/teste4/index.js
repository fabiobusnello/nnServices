const component = () => {
    return `<div style="background-color:#fff">teste4</div>`
}
const teste4 = ()=>{
    document.querySelector(".contents").innerHTML = component()
}

export default teste4