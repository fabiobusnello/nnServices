const component = () => {
    return `<div style="background-color:#fff">teste5</div>`
}
const teste5 = ()=>{
    document.querySelector(".contents").innerHTML = component()
}

export default teste5