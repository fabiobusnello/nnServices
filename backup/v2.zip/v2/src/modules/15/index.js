const component = () => {
    return `<div style="background-color:#fff">15</div>`
}
const 15 = ()=>{
    document.querySelector(".contents").innerHTML = component()
}

export default 15