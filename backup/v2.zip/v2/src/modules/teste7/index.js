const component = () => {
    return `<div style="background-color:#fff">teste7</div>`
}
const teste7 = ()=>{
    document.querySelector(".contents").innerHTML = component()
}

export default teste7