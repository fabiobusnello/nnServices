const component = () => {
    return `<div style="background-color:#fff">contratos</div>`
}
const contracts = ()=>{
    document.querySelector(".contents").innerHTML = component()
}

export default contracts