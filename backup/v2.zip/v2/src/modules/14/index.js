const component = () => {
    return `<div style="background-color:#fff">14</div>`
}
const 14 = ()=>{
    document.querySelector(".contents").innerHTML = component()
}

export default 14