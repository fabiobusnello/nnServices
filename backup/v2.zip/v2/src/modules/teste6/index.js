const component = () => {
    return `<div style="background-color:#fff">teste6</div>`
}
const teste6 = ()=>{
    document.querySelector(".contents").innerHTML = component()
}

export default teste6