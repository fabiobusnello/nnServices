const component = () => {
    return `<div style="background-color:#fff">teste</div>`
}
const teste = ()=>{
    document.querySelector(".contents").innerHTML = component()
}

export default teste