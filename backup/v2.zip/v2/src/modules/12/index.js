const component = () => {
    return `<div style="background-color:#fff">12</div>`
}
const 12 = ()=>{
    document.querySelector(".contents").innerHTML = component()
}

export default 12