const component = () => {
    return `<div style="background-color:#fff">testd9</div>`
}
const testd9 = ()=>{
    document.querySelector(".contents").innerHTML = component()
}

export default testd9