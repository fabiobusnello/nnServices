import './globals'
import login from './modules/login';

login()