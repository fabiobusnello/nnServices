const modules = async (app)=>{
    app.get('/modules', require('./get'))
    app.post('/modules', require('./create-module'))
}
/*(req, res)=>{
        console.log(req.body)
        res.json({status: true, message: 'testando'})
    }*/
module.exports = modules