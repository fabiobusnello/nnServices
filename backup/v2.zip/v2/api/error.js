'use strict'
const error = {
    status: false,
    message: '',
    httpStatus: 500
}
module.exports = error